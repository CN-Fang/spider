import re

s = 'A B C D'
p1 = re.compile('\w+\s+\w+')
r1 = p1.findall(s)
print(r1)

p2 = re.compile('(\w+)\s+\w+')
r2 = p2.findall(s)
print(r2)

p3 = re.compile('(\w+)\s+(\w+)')
r3 = p3.findall(s)
print(r3)