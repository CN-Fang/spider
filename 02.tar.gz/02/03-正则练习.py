import re

html = '''
<div class='animal'>
    <p class='name'>
        <a title='tiger'></a>
    </p>
    <p class='contents'>
        Two tigers two tigers run fast
    </p>
</div>
<div class='animal'>
    <p class='name'>
        <a title='rabbit'></a>
    </p>
    <p class='contents'>
        Small white rabbit white and white
    </p>
</div>
'''
p = re.compile("<a title='(.*?)'></a>.*?class='contents'>(.*?)</p>",re.S)
r = p.findall(html)

for i in r:
    print('动物名称:', i[0].strip())
    print('动物描述:', i[1].strip())