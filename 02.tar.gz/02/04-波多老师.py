import requests

url = 'http://s9.rr.itc.cn/g/3/2Y/N3ANvqm.jpg'
headers = {"User-Agent":"Mozilla/5.0"}

res = requests.get(url, headers = headers)
res.encoding = 'utf-8'
html = res.content

with open('波多.jpg', 'wb') as f:
    f.write(html)
print('波多老师已到硬盘!')