import re
import urllib.request
import urllib.parse

class NeihanSpider(object):
    def __init__(self):
        self.headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"}
        self.baseurl = "https://www.neihan8.com/njjzw/"
        self.page = 1
    
    def getPage(self, url):
        req = urllib.request.Request(url, headers = self.headers)
        res = urllib.request.urlopen(req)
        html = res.read().decode('utf-8')
        self.parsePage(html)
    
    def parsePage(self, html):
        p = re.compile('<div class="text-column-item.*?class="title" title="(.*?)">.*?class="desc">(.*?)</div>',re.S)
        r_list = p.findall(html)
        # r_list:[('题','答案'),(),()...]
        self.writePage(r_list)
    
    def writePage(self, r_list):
        for r_tuple in r_list:
            for r_str in r_tuple:
                with open('脑筋急转弯.txt', 'a', encoding='gb18030') as f:
                    f.write(r_str.strip() + '\n')
                    print(r_str.strip())
    
    def workOn(self):
        self.getPage(self.baseurl)
        while True:
            c = input('成功,是否继续(y/n):')
            if c.strip().lower() == 'y':
                self.page += 1
                url = self.baseurl + 'index_'+str(self.page)+".html"
                self.getPage(url)
            else:
                print('爬取结束,谢谢使用本蜘蛛')
                break
    
if __name__ == '__main__':
    spider = NeihanSpider()
    spider.workOn()

