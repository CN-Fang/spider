import requests

url = 'https://s.taobao.com/search?&imgfile=&js=1&stats_click=search_radio_all%3A1&initiative_id=staobaoz_20181124&ie=utf8&bcoffset=4&ntoffset=4&p4ppushleft=1%2C48'
key = input("请输入搜索内容:")
params = {'%q':key}
headers = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75 Safari/537.36"}

res = requests.get(url, params=params, headers = headers)
res.encoding="gbk"
print(res.text)