import urllib.request
import urllib.parse
import re, csv

class MaoyanSpider():
    def __init__(self):
        self.baseurl = 'http://maoyan.com/board/4?offset='
        self.headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"}
        self.offset = 0
        self.page = 1

    # 获取页面
    def getPage(self, url):
        req = urllib.request.Request(url, headers = self.headers)
        res = urllib.request.urlopen(req)
        html = res.read().decode('utf-8')
        self.parsePage(html)

    # 解析页面
    def parsePage(self, html):
        p = re.compile('<div class="movie-item-info">.*?title="(.*?)".*?class="star">(.*?)</p>.*?class="releasetime">(.*?)</p>',re.S)
        r_list = p.findall(html)
        self.writeTocsv(r_list)

    # 保存数据
    def writeTocsv(self, r_list):
        for r_tuple in r_list:
            L = [r_tuple[0].strip(), r_tuple[1].strip(), r_tuple[2].strip()]
            with open('猫眼电影.csv', 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(L)

    # 主函数
    def workOn(self):
        while True:
            c = input('你确定爬???!!!(y/n)')
            if c.strip().lower() == 'y':
                url = self.baseurl + str(self.offset)
                self.getPage(url)
                self.page += 1
                self.offset = (self.page-1)*10
            else:
                print('爬取结束')
                break
        

if __name__ == '__main__':
    spider = MaoyanSpider()
    spider.workOn()