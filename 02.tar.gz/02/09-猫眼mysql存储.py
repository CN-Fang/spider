import urllib.request
import urllib.parse
import re, pymysql
import warnings

class MaoyanSpider():
    def __init__(self):
        self.baseurl = 'http://maoyan.com/board/4?offset='
        self.headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"}
        self.offset = 0
        self.page = 1
        # 连接对象
        self.db = pymysql.connect('localhost', 'root', '123456', charset='utf8')
        # 游标对象
        self.cursor = self.db.cursor()

    # 获取页面
    def getPage(self, url):
        req = urllib.request.Request(url, headers = self.headers)
        res = urllib.request.urlopen(req)
        html = res.read().decode('utf-8')
        self.parsePage(html)

    # 解析页面
    def parsePage(self, html):
        p = re.compile('<div class="movie-item-info">.*?title="(.*?)".*?class="star">(.*?)</p>.*?class="releasetime">(.*?)</p>',re.S)
        r_list = p.findall(html)
        self.writeTomysql(r_list)

    # 保存数据
    def writeTomysql(self, r_list):
        c_db = 'create database if not exists myfilm charset utf8'
        u_db = 'use myfilm'
        c_tab = 'create table if not exists top100(\
                id int primary key auto_increment,\
                name varchar(50),\
                star varchar(100),\
                time varchar(50)\
                )'
        ins = 'insert into top100(name,star,time)\
                values(%s,%s,%s)'
        # 过滤警告
        warnings.filterwarnings('ignore')
        try:
            self.cursor.execute(c_db)
            self.cursor.execute(u_db)
            self.cursor.execute(c_tab)
        except:
            pass

        # 插入数据
        for r_tuple in r_list:
            L = [r_tuple[0].strip(),r_tuple[1].strip(),r_tuple[2].strip()]
            # execute(ins, [列表])
            self.cursor.execute(ins, L)
            self.db.commit()
            print("存入成功!")

    # 主函数
    def workOn(self):
        while True:
            c = input('你确定爬???!!!(y/n)')
            if c.strip().lower() == 'y':
                url = self.baseurl + str(self.offset)
                self.getPage(url)
                self.page += 1
                self.offset = (self.page-1)*10
            else:
                print('爬取结束')
                break
        

if __name__ == '__main__':
    spider = MaoyanSpider()
    spider.workOn()