import urllib.request
import urllib.parse
import re, pymongo

class MaoyanSpider():
    def __init__(self):
        self.baseurl = 'http://maoyan.com/board/4?offset='
        self.headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"}
        self.offset = 0
        self.page = 1
        # 连接对象
        self.conn = pymongo.MongoClient('localhost', 27017)
        # 数据库对象
        self.db = self.conn.myfilm
        # 集合对象
        self.tab = self.db.top100

    # 获取页面
    def getPage(self, url):
        req = urllib.request.Request(url, headers = self.headers)
        res = urllib.request.urlopen(req)
        html = res.read().decode('utf-8')
        self.parsePage(html)

    # 解析页面
    def parsePage(self, html):
        p = re.compile('<div class="movie-item-info">.*?title="(.*?)".*?class="star">(.*?)</p>.*?class="releasetime">(.*?)</p>',re.S)
        r_list = p.findall(html)
        self.writeTomongo(r_list)

    # 保存数据
    def writeTomongo(self, r_list):
        for r_tuple in r_list:
            name = r_tuple[0].strip()
            star = r_tuple[1].strip()
            time = r_tuple[2].strip()
            d = {'name':name, "star":star, "time":time}
            self.tab.insert(d)
            print('存入数据库成功!')

    # 主函数
    def workOn(self):
        while True:
            c = input('你确定爬???!!!(y/n)')
            if c.strip().lower() == 'y':
                url = self.baseurl + str(self.offset)
                self.getPage(url)
                self.page += 1
                self.offset = (self.page-1)*10
            else:
                print('爬取结束')
                break
        

if __name__ == '__main__':
    spider = MaoyanSpider()
    spider.workOn()