import requests, random

url = "http://httpbin.org/get"
headers = {"User-Agent" : "Fang"}
proxies = {'https':"http://309435365:szayclhp@116.255.162.107:16816"}
# for _ in range(10):
res = requests.get(url, proxies=proxies, headers=headers, timeout=3)
res.encoding = "utf-8"
print(res.text)
