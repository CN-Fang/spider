import requests

url = "http://www.tmooc.cn/"
headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75 Safari/537.36"}
# True为进行认证,False为不需要认证
res = requests.get(url, headers = headers, verify=False)
res.encoding = 'utf-8'
print(res.text)