import json

jobj = '{"city":"北京"}'
jarray = '["北京","上海"]'

# 转为python格式
D = json.loads(jobj)
L = json.loads(jarray)
print(type(D),D)
print(type(L),L)