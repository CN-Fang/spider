import json

# Python格式
D = {"name":"死侍"}
L = [1,2,3]
T = (4,5,6)
# 转为json格式
JD = json.dumps(D, ensure_ascii=False)
JL = json.dumps(L)
JT = json.dumps(T)

print(type(JD),JD)
print(type(JL),JL)
print(type(JT),JT)

