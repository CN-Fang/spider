import requests
import pymysql
import json


class DoubanSpider:
    def __init__(self):
        self.url = 'https://movie.douban.com/j/chart/top_list?'
        self.headers = {'User-Agent':'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)'}
        self.db = pymysql.connect('localhost', 'root', '123456', 'DouBan', charset='utf8')
        self.cursor = self.db.cursor()

    def getPage(self, params):
        res = requests.get(self.url, headers=self.headers, params=params)
        res.encoding = 'utf-8'
        html = res.text
        self.parsePage(html)

    def parsePage(self, html):
        # html为json格式的字符串
        info = json.loads(html)
        # for循环来遍历列表中的元素[{1个电影信息},{},{}...]
        for film in info:
            name = film["title"]
            score = float(film["score"].strip())
            # 定义成列表,为了存入mysql使用
            exe_list = [name, score]
            self.writeTomysql(exe_list)
        print("成功存入数据库Douban.Film")

    def writeTomysql(self, exe_list):
        ins = "insert into Film(name,score) values(%s,%s)"
        self.cursor.execute(ins, exe_list)
        self.db.commit()

    def workOn(self):
        number = input("请输入要爬取的数量:")
        params = {
            'type' : '11',
            'interval_id' : '100:90',
            'action' : '',
            'start' : '0',
            'limit' : number
            }
        self.getPage(params)
        # 断开数据库连接
        self.cursor.close()
        self.db.close()

if __name__ == '__main__':
    spider = DoubanSpider()
    spider.workOn()