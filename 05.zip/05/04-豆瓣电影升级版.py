import requests
import pymysql
import json


class DoubanSpider:
    def __init__(self):
        self.url = 'https://movie.douban.com/j/chart/top_list?'
        self.headers = {'User-Agent':'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)'}
        self.db = pymysql.connect('localhost', 'root', '123456', 'DouBan', charset='utf8')
        self.cursor = self.db.cursor()

    def getPage(self, params):
        res = requests.get(self.url, headers=self.headers, params=params)
        res.encoding = 'utf-8'
        html = res.text
        self.parsePage(html)

    def parsePage(self, html):
        # html为json格式的字符串
        info = json.loads(html)
        # for循环来遍历列表中的元素[{1个电影信息},{},{}...]
        for film in info:
            name = film["title"]
            score = float(film["score"].strip())
            # 定义成列表,为了存入mysql使用
            exe_list = [name, score]
            self.writeTomysql(exe_list)
        print("成功存入数据库Douban.Film")

    def writeTomysql(self, exe_list):
        ins = "insert into Film2(name,score) values(%s,%s)"
        self.cursor.execute(ins, exe_list)
        self.db.commit()

    def workOn(self):
        kinds=["剧情","喜剧","爱情"]
        tpLlist = {
            "剧情":'11',
            "喜剧":'24',
            "爱情":'13'
            }
        print("*******************")
        print("|剧情|喜剧|爱情|")
        print("*******************")
        kind = input("请输入电影类型:")
        if kind in kinds:
            number = input("请输入要爬取的数量:")
            filmType = tpLlist[kind]
            params = {
                'type' : filmType,
                'interval_id' : '100:90',
                'action' : '',
                'start' : '0',
                'limit' : number
                }
            self.getPage(params)
            # 断开数据库连接
            self.cursor.close()
            self.db.close()
        else:
            print("您输入的电影类型不存在,感谢使用!")

if __name__ == '__main__':
    spider = DoubanSpider()
    spider.workOn()