#导入webdriver
from selenium import webdriver
import time
#创建浏览器对象，发请求
driver = webdriver.Chrome()
driver.get('http://www.qiushibaike.com/')
#单元素查找
rOne = driver.find_element_by_class_name("content")
print(rOne.text)
#多元素查找,得到的结果为列表
rMany = driver.find_elements_by_class_name("content")
for r in rMany:
    print(r.text)
#print(type(rMany), len(rMany))
driver.quit()