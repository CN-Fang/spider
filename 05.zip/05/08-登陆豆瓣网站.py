#导入webdriver
from selenium import webdriver
import time
#创建浏览器对象，发请求
driver = webdriver.Chrome()
driver.get('https://www.douban.com/')
#截图,验证码
driver.save_screenshot("验证码.png")
#找用户名，密码，验证码，登陆豆瓣按钮
#用户名
uname = driver.find_element_by_name("form_email")
uname.send_keys("296218845@qq.com")
#密码
pwd = driver.find_element_by_name("form_password")
pwd.send_keys("fj20082135131")
#验证码在终端输入
yzm = driver.find_element_by_id("captcha_field")
key = input("验证码-->>>")
yzm.send_keys(key)
#点击登陆按钮
time.sleep(5)
login = driver.find_element_by_class_name("bn-submit")
login.click()
time.sleep(3)
#获取截图
driver.save_screenshot("登陆.png")
driver.quit()