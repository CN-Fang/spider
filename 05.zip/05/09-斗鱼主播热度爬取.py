from selenium import webdriver
from lxml import etree
import csv


#创建浏览器对象，发请求
driver = webdriver.Chrome()
driver.get("https://www.douyu.com/directory/all")

class DouyuSpider:
    def __init__(self):
        pass
    
    # 获取主播名称，观众数量
    def getData(self):
        #创建xpath解析对象
        parseHtml = etree.HTML(driver.page_source)
        names = parseHtml.xpath('//div[@id="live-list-content"]//span[@class="dy-name ellipsis fl"]/text()')
        numbers = parseHtml.xpath('//div[@id="live-list-content"]//span[@class="dy-num fr"]/text()')
        # names:['主播1','主播2'...]
        # numbers:["90-8万","90万"....]
        for name,number in zip(names,numbers):
            L = [name,number]
            self.writeData(L)
    
    # 保存到csv文件
    def writeData(self, L):
        with open("斗鱼直播.csv", 'a', newline="", encoding="gb18030") as f:
            writer = csv.writer(f)
            writer.writerow(L)
            
    def workOn(self):
        while True:
            self.getData()
            # 如果找不到不能点的下一页的class,去点击下一页
            if driver.page_source.find("shark-pager-next shark-pager-disable shark-pager-disable-next")==-1:
                driver.find_element_by_class_name("shark-pager-next").click()
            else:
                print('爬取完成!')
                break
    
if __name__ == "__main__":
    spider = DouyuSpider()
    spider.workOn()

































#name = '//div[@id="live-list-content"]//span[@class="dy-name ellipsis fl"]'
#hotnum = '//div[@id="live-list-content"]//span[@class="dy-num fr"]'
#xiayiye(no)  class="shark-pager-next shark-pager-disable shark-pager-disable-next"
#xiayuye(yes) class="shark-pager-next"