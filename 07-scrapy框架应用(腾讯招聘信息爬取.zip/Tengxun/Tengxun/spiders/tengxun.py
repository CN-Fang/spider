# -*- coding: utf-8 -*-
import scrapy
from Tengxun.items import TengxunItem

class TengxunSpider(scrapy.Spider):
    name = 'tengxun'
    allowed_domains = ['hr.tencent.com']
    # 定义一个基准的url, 为了方便后期拼接290个url
    url = 'https://hr.tencent.com/position.php?start='
    start = 0
    # 拼接初始的url
    start_urls = [url + str(start)]

    # parse函数是第一次从start_urls中初始url发请求,得到响应后必须要调用的函数
    def parse(self, response):
        for i in range(0,2891,10):
            # scrapy.Request()构建请求对象,可放到生成器管道处理,默认可去重
            # 把290页的url给调度器入队列,然后出队列给下载器
            yield scrapy.Request(self.url + str(i), callback=self.parseHtml)

    def parseHtml(self, response):
        #每个职位的节点对象列表
        baseList = response.xpath('//tr[@class="even"] | //tr[@class="odd"]')
        for base in baseList:
            item = TengxunItem()
            item['zhName'] = base.xpath('./td[1]/a/text()').extract()[0]
            item['zhLink'] = base.xpath('./td[1]/a/@href').extract()[0]
            item['zhType'] = base.xpath('./td[2]/text()').extract()
            if item["zhType"]:
                item["zhType"] = item['zhType'][0]
            else:
                item['zhType'] = '无'
            item['zhNum'] = base.xpath('./td[3]/text()').extract()[0]
            item['zhAddress'] = base.xpath('./td[4]/text()').extract()[0]
            item['zhTime'] = base.xpath('./td[5]/text()').extract()[0]
            yield item