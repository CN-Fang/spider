#!/bin/sh
/usr/local/bin/sslocal -c Tokyo1.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c Tokyo2.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c shadowsocks_bj3.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c shadowsocks_bj4.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c LA01.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c LA02.json -b 127.0.0.1 &
#/usr/local/bin/sslocal -c London.json -b 127.0.0.1 &
#/usr/local/bin/sslocal -c LA.json -b 127.0.0.1 &
#/usr/local/bin/sslocal -c GuiGu.json -b 127.0.0.1 &
cd /usr/local/etc/ && /usr/local/bin/3proxy 3proxy1.cfg && /usr/local/bin/3proxy 3proxy2.cfg && /usr/local/bin/3proxy 3proxy3.cfg && /usr/local/bin/3proxy 3proxy4.cfg && /usr/local/bin/3proxy 3proxy5.cfg  && /usr/local/bin/3proxy 3proxy6.cfg
