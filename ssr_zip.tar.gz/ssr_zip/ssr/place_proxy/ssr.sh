#!/bin/sh
/usr/local/bin/sslocal -c Japan.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c Singapore.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c Paris.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c Frankfurt.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c London.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c LA.json -b 127.0.0.1 &
/usr/local/bin/sslocal -c GuiGu.json -b 127.0.0.1 &
cd /usr/local/etc/ && /usr/local/bin/3proxy 3proxy1.cfg && /usr/local/bin/3proxy 3proxy2.cfg && /usr/local/bin/3proxy 3proxy3.cfg && /usr/local/bin/3proxy 3proxy4.cfg && /usr/local/bin/3proxy 3proxy5.cfg && /usr/local/bin/3proxy 3proxy6.cfg && /usr/local/bin/3proxy 3proxy7.cfg
