#!/bin/sh
#Au:Bojingqian
port=$1
PID=`lsof -i:$port |awk '{print $2}' | tail -n 1`
if [ -z $PID ]; then
    echo "$port Vacant"
else
    echo "port: $port PID: $PID"
    `kill -9 $PID`
    FPID=`lsof -i:$port |awk '{print $2}' | tail -n 1`
    if [ -u $FPID ]; then
        echo "Kill success"
    else 
        echo "Kill Fail"
    fi
fi
