#!/bin/sh
cd /usr/local/etc/ && /usr/local/bin/3proxy 3proxy1.cfg && /usr/local/bin/3proxy 3proxy2.cfg && /usr/local/bin/3proxy 3proxy3.cfg && /usr/local/bin/3proxy 3proxy4.cfg && /usr/local/bin/3proxy 3proxy5.cfg && /usr/local/bin/3proxy 3proxy6.cfg && /usr/local/bin/3proxy 3proxy7.cfg
