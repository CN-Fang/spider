#!/bin/sh
#Au:Bojingqian
. /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1081 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1082 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1083 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1084 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1085 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1086 && . /home/python/ssr_zip/ssr/place_proxy/stop_port.sh 1087
pkill 3proxy
