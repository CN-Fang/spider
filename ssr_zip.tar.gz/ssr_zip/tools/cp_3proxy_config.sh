#!/bin/sh
cd 3pconfig && cp 3proxy1.cfg /usr/local/etc/3proxy1.cfg
cp 3proxy2.cfg /usr/local/etc/3proxy2.cfg
cp 3proxy3.cfg /usr/local/etc/3proxy3.cfg
cp 3proxy4.cfg /usr/local/etc/3proxy4.cfg
cp 3proxy5.cfg /usr/local/etc/3proxy5.cfg
cp 3proxy6.cfg /usr/local/etc/3proxy6.cfg
cp 3proxy7.cfg /usr/local/etc/3proxy7.cfg
