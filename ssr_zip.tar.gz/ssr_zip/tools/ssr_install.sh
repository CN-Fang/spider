#!/bin/sh
cd shadowsocksr-manyuser && python3 setup.py install && cd .. && cd libsodium-1.0.11 && ./configure && make -j2 && make install && echo /usr/local/lib > /etc/ld.so.conf.d/usr_local_lib.conf && ldconfig && cd .. && cd 3proxy-0.8.10/ && make -f Makefile.Linux && make -f Makefile.Linux install && cd .. && bash cp_3proxy_config.sh && pwd
